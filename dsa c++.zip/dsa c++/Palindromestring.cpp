// C++ program for the above approach
// #include <bits/stdc++.h>
#include <algorithm>
#include<iostream>
#include<string>

using namespace std;

int main(){
    // string S="aba";
    string S;
    cout << "enter string: ";
    cin >> S;
    string P=S;

    reverse(S.begin(),S.end());
    // check reverse match or not
    if(P==S){
        cout << "match";
    }
    else{
        cout << "not match";
    }
    // 
    // reverse the sentence
     cout << S; 
}
