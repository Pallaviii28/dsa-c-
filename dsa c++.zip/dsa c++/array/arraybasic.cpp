#include<iostream>
using namespace std;

int main(){

    int num[20];

    cout <<"value of 5 is " << num[5] << endl;
    // cout<<endl;
    cout <<"value of 1 is " << num[1] << endl;
    cout<<endl;

    cout << "next line start here...";
    cout<<endl;

    int number[3]={2,4,5};
    cout <<"value of 1 is " << number[1] << endl;
    cout <<"value of 2 is " << number[2] << endl;


    int one[10]={};
    int n=10;

    for(int i=0; i<n; i++){
        cout<< one[i]<< " ";
    }cout<<endl;

    int arr[100];

    int s=sizeof(arr)/sizeof(int);
    cout<< "size of array is "<< s << endl;

    char p[3]={'e','o','y'};

    for(int i=0; i<3; i++){
       cout << p[i]<<" ";
    }
    














    

}