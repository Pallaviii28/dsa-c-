#include<iostream>
using namespace std;

int getMin(int a[],int n){

    int mini=4567;
    for(int i =0; i<n; i++){
        mini=min(mini, a[i]);
    }
}

int main(){
    int arr[]={3,66,8,90,3,-4,2};

    cout <<"enter size";
    int n;
    cin >> n;

    int ans= getMin(arr,n);
    cout << "min is: " << ans;

}