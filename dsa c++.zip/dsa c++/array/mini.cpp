#include<iostream>
using namespace std;

int getMinMax(int a[],int n){

    int mini=4567;
    int maxi=-45;
    for(int i =0; i<n; i++){
        mini=min(mini, a[i]);
        maxi=max(maxi,a[i]);
    }
    return mini;
    return maxi;
}

int main(){
    int arr[]={3,66,8,90,3,-4,2};

    cout <<"enter size ";
    int n;
    cin >> n;

    for(int i=0; i<n; i++){
        cin >> arr[i];
    }

    int ans= getMinMax(arr,n);
    cout << "min is: " << ans << " "<< "maxi " << ans;

}