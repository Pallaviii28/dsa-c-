// #include <iostream>
// using namespace std;

// int main()
// {

//     cout << "enter the value of array";

//     int n;
//     cin >> n;

//     int arr[n];
//     for (int i = 0; i < n; i++)
//     {
//         cin >> arr[i];
//     }

//     // find max array value
//     int ma = 0;
//     for (int i = 0; i < n; i++)
//     {
//         ma = max(ma, arr[i]);
//     }

//     int fre[ma + 1] = {0};
//     for (int i = 0; i < n; i++)
//     {
//         fre[arr[i]]++;
//     }

//     for (int i = 0; i < ma + 1; i++)
//     {
//         if (fre[i] != 0)
//         {
//             cout << i << "->" << fre[i] << endl;
//         }
//     }
// }

// #include <iostream>
// using namespace std;

// int main(){

//     cout<<"enter array size";
//     cout<<endl;

//     int n;
//     cin>>n;

//     int arr[100];

//     for(int i=0; i<n; i++){
//         cin>>arr[i];
//     }        

//     int ma=0;
//     for(int i=0;i<n;i++){
//         ma=max(ma,arr[i]);
//     }

//     int freq[ma+1]={0};
//      for(int i=0;i<n;i++){
//         freq[arr[i]]++;
//      }


//     for(int i=0; i<ma+1; i++){
//         if(freq[i]!=0){
//             cout<<i<<"->"<<freq[i]<<endl;
//         }
//     }

}