#include <iostream>
using namespace std;

int main(){

    cout<<"enter array size";
    cout<<endl;

    int n;
    cin>>n;

    int arr[100];


    for(int i=0; i<n; i++){
        cin>>arr[i];
    
    }   

}
