#include <iostream>
#include <cctype>
#include<string.h>
using namespace std;

int main() {

  // convert 'a' to uppercase
//   char ch = tolower('A');
//    char ch1 = toupper('a');


//   cout << "uppercase ->" << ch << "\n" ;
//   cout << "lowercase ->" << ch1 ;

//   return 0;



// COMPARE 2 STRINGGGG

//   string s1="Pallavi";
//   string s2="Pallaviii";

//   if(s1==s2)
// {
//     cout << "both same: ";
//   }
//   else{
//     cout << "both are not same: ";
//   }


// concatation 2 string

  string s1="Pallavi";
  string s2="Pallaviii";

//   string s3=s1+ " " + s2;
  //   cout << s3;

//   both can use 
  s1.append(s2);
  cout << s1;


    
}

