#include <iostream>
using namespace std;

int main()
{

    // int n, n1=0, n2=1, n3, sum;

    //  cout << "enter a number: ";
    //  cin >> n;
    //  cout << n1 << " " <<n2 << " ";

    //  for( int i=2; i<=n; i++){
    //     n3 =n1+n2;
    //     cout <<n3 << " " ;
    //     n1=n2;
    //     n2=n3;
    //  }

    int n, rev = 0, i, orig;
    cout << "enter a number: ";
    cin >> n;
    orig = n;

    while (n > 0)
    {

        rev = (rev*10) +( n % 10);
        n = n / 10;
    }
    cout <<rev;

    if (orig == rev)
    {
        cout << "factorial no ";
    }
    else
    {
        cout << " not a factorial num ";
    }
}