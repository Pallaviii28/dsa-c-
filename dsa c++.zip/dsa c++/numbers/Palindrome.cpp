#include<iostream>
using namespace std;

int main(){

    int n,rev=0, orig;

    cout << "enter a num: ";
    cin >> n;

    orig=n;

    while (n >0){
        rev=(rev*10)+n%10;
        n=n/10;
    }
    cout << rev << " ";

    if(orig==rev){
        cout << "match";
    }
    else{
        cout << "not match: ";
    }
}