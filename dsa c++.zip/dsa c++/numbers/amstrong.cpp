#include <iostream>
using namespace std;


int main(){

    int num, i,sum=0, orig;

    cout << "enter num: ";
    cin >> num;

    orig=num;

    while(num>0){
        sum=sum+(num%10)*(num%10)*(num%10);
        num=num/10;
    }
    cout << sum << " ";

    if(orig==sum){
        cout << "Amstrong number: ";
    }
    else{
         cout << " not a Amstrong number: ";
    }
}