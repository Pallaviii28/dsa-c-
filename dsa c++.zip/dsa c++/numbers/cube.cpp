# include<iostream>
#include<cmath>
using namespace std;


int main(){

    int num;

    cout << "enter num: ";
    cin >> num; 

    
    int sq = sqrt(num);
    int cb= cbrt(num);

    cout << "square root is : " << sq <<"\n ";
    cout << "cube root is : " << sq;
}