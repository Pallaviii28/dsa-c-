#include <iostream>
using namespace std;

int main(){
    int n1,n2;
    int gcd=1,lcm=1;

    cout << "enter 2 num: ";
    cin >> n1 >> n2 ;

    for (int i=1; i<1000; i++){
        if ((n1%i==0) && (n2%i==0)){
            gcd=i;
        }
        // cout << gcd;
    }

    


    lcm=(n1*n2)/gcd;

    cout <<  "value of  gcd n1 & n2 is : " << n1 << " " << n2 <<" " << gcd << endl;
    cout <<  "value of  lcm n1 & n2 is : " << n1 << " " << n2  <<" " << lcm;
}