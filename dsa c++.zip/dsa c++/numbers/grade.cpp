#include <iostream>
using namespace std;

char finalGrade(int score)
{
    switch (score / 10)
    {
    case 10:
    case 9:
        return 'A';
    case 8:
        return 'B';
    case 7:
        return 'c';
    case 6:
        return 'D';

    default:
        break;
    }
}

int main()
{
    int score;
    char  grade;
    cout << "enter score betwen 0-100: ";
    cin >> score;

    grade=finalGrade(score);

    if(score<0 || score>100){
        return 0;
    }
    else{
        cout << "grade is : " << grade;
    }
}