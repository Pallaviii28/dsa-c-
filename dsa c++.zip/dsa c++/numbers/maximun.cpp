#include<iostream>
using namespace std;

int max(int num1, int num2, int num3){
    if (num1 > num2 && num1 > num3){
        return num1;
    }
    else if (num2 > num1 && num2 > num3)
    {
        return num3;
    }
    else{
        return num3;
    }
    
}

int main(){
    int a,b,c;

    cout << "enter 3 num: ";
    cin >> a >> b >> c;

  cout << "maximum num is: " << max(a,b,c);

}