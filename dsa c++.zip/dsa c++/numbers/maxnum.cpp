
#include <iostream>
using namespace std;

int getMax(int arr[], int n)
{
    int maxi = -53;
    for (int i = 0; i < n; i++)
    {
        maxi = max(maxi, arr[i]);
    }
    return maxi;
}

int getMini(int arr[], int n)
{
    int mini = 53;
    for (int i = 0; i < n; i++)
    {
        mini = min(mini, arr[i]);
    }
    return mini;
}

int main()
{

    int arr[100] = {22, 3, 4, 5, 11, -4, -5, 88};

    int num, i;
    cout << "enter num: ";
    cin >> num;

    for (i = 0; i < num; i++)
    {
        cin >> arr[i];
    }

    cout << "maximum number is: " << getMax(arr, num) << endl;

    cout << "minimum number is: " << getMini(arr, num);
}