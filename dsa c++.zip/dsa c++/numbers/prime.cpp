
#include<iostream>
using namespace std;

int main(){
    int num;
    cout << "enter num:";
    cin >> num;

    for(int i=2; i<num; i++){
        if(num % i==0){
            cout << "even num:";
            break;
        }
        else{
            cout << "odd num:";
            break;
        }
    }
}