#include<iostream>
using namespace std;

int BinarySearch(int arr[] ,int n,int key){
    
    int left=0;
    int right=n;

    while(left <= right){
      
      int mid= (left+right)/2;

      if(arr[mid]==key)
        return mid;
      
       if(arr[mid] < key)
        left=mid+1;
      
      else
        right=mid-1;
      
    }
    
}


int main(){
    // int arr[100]= {11,2,45,6,4,67,-4,-2,77};

    int n;
    cout << "enter the element...";
    cin >> n;

    int key;
    cin >> key;

    int arr[n];

    for(int i=0; i<n; i++){
        cin >> arr[i];
    }
 
    // cout << BinarySearch(arr,n,key) << endl;

    int ff= BinarySearch(arr,n,key);

    if(ff){
        cout << " found" ;
    }
    else{
        cout << "not found";
    }
    return 0;
}