#include<iostream>
using namespace std;

int search(int arr[] ,int n,int key){

    for(int i=0; i<n; i++){
        if(arr[i]==key){
            return 1;
        }
    }
    return 0;
}


int main(){
    int arr[100]= {11,2,45,6,4,67,-4,-2,77};

    cout << "enter the element search here...";
    int key;
    cin >> key;
 
    int ff=search(arr, 100,key);

    if(ff){
        cout << " found";
    }
    else{
        cout << "not found";
    }
    return 0;


}



// #include<iostream>
// using namespace std;

// int linearSearch(int arr[], int n, int key){
//     for(int i=0; i<n; i++){
//         if(arr[i]==key)
//         return i;
//     }
//     return -1;
// }

// int main()
// {
//     int i, n;

//     cout << "enter num: ";
//     cin >> n;

//     int arr[n];

//     for(int i=0; i<n; i++){
//         cin >> arr[i];
//     }

//     int key;
//     cin>>key;

//     cout<<linearSearch(arr,n,key)<<endl;


// }
