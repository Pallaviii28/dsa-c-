

#include <iostream>
#include <bits/stdc++.h>

using namespace std;

int main()
// lower to upper case  solve diff method

// method 1 using transform stl for big string

// {
//     string str = "lorembhbhgvcfc";
//     transform(str.begin(), str.end(), str.begin(), ::toupper);
//     cout << "uppercase\n"
//          << str;

//     cout << endl;

//     string str2 = "ABCGS";
//     transform(str2.begin(), str2.end(), str2.begin(), ::tolower);
//     cout << "lowecase\n"
//          << str2;
// }


// methodd 2 (uppercase)

// {
//     char x;
//     cout << "enter string: ";
//     cin >> x;
//     x=x-32;
//     cout << x;
// }


// methodd 2 (lowercase)

// {
//     char x;
//     cout << "enter string: ";
//     cin >> x;
//     x=x+32;
//     cout << x;
// }


// {
//     string str;
//     cout << " enter string ";
//     cin >> str;

//     for( int i=0 ; i<str.size(); i++){
//         putchar(tolower(str[i]));
//         // put method is used to display output on screen
//     }
// }


// uppercse

// {
//     string str;
//     cout << " enter string ";
//     // cin >> str;
//     getline(cin, str);

//     for( int i=0 ; i<str.size(); i++){
//         putchar(toupper(str[i]));
//         // put method is used to display output on screen
//     }
// }