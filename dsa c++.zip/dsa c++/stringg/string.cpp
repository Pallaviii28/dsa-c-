#include <iostream>
#include <bits/stdc++.h>

using namespace std;

int main()

//  copy 1 string to another
// {

//     string s1, s2;
//     cout << "enter a string: ";
//     cin >> s1;

//     s2 = s1;
//     cout << "s1 ->" << s1 << endl;
//     cout << "s2 ->" << s2;
// }

// erase character

// {
//     string s;
//     cout << "enter a string: ";
//     cin >> s;

//     cout << "display a string " << s <<endl ;
//     s.erase(2,6);
//     cout<< "display after erase: " << s;
// }

// declarre a string

// {
//     string str="helllo";

//     cout << str << endl;
//     str.erase(2,5);
//     cout<< "after delete\n"<< str;
// }

// ######  length

// {
//     string s1="this is c language:\n";
//     string s2="c++";

//     cout << "s1-> " << s1;
//     s1.replace(8,1,s2);
//     cout << s1;

// }

// {
//     string s;
//     cout << "enter a string: ";
//     cin >> s;

//     cout << "display a string length:\n " << s.size();

// }

// {
//     char x;
//     cout << "enter string";
//     cin >> x;
//     if (islower(x))
//         cout << "Lowercase";
//     else
//         cout << " uppercase.";

//     return 0;
// }

// {
//     // string str ="hdhhbe  bhhhe ne";

//     string str;

//     cout << "enter string:  ";
//     getline(cin, str);

//     cout << "output" << str;
// }

// {
//         char str1[100], str2[100];

//         cout << "enter string1: ";
//         gets(str1);

//         cout << "enter string2: ";
//         gets(str2);

//         if (strcmp(str1, str2) == 0)
//         {
//                 cout << " equal string";
//         }
//         else{
//                 cout << "not equal string:";
//         }
// }

// revserse string

// {
//         string s ="hello";

//         reverse(s.begin(), s.end());
//         cout << s;
// }


// another methodd 

// {
//         char s []="hello";
//         strrev(s);
//         cout << s;
// }

// revserse string using temp variable

// {
//         string str;
//         string s = "hello";
//         int n = s.size();

//         cout << "original string: " << s << endl;

//         for (int i = n; i >= 0; i--)
//                 str.push_back(s[i]);

//         cout << str;
// }




